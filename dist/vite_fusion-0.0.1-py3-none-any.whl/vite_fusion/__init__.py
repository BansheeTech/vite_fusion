"""
vite_fusion.py
"""

import os
import json


def register_vite_assets(app, dev_mode=True, dev_server_url="http://localhost:5173", manifest_path="src/dist/.vite/manifest.json", nonce_provider=None, logger=None):
    """
    Registra funciones de plantilla para integrar assets generados por Vite.

    Parámetros:
        app (Flask): La instancia de Flask.
        dev_mode (bool): Si True, se asume que el servidor de Vite está en marcha
                         y se cargan scripts desde dev_server_url.
        dev_server_url (str): URL del servidor de Vite en desarrollo (ej: "http://localhost:5173").
        manifest_path (str): Ruta al manifest.json generado por Vite en producción.
        nonce_provider (callable|None): Función sin argumentos que devuelve el nonce (string) o None.
                                        Si es None, no se añade el atributo nonce a los scripts.
        logger (logging.Logger|None): Logger opcional. Si None, no se registran advertencias ni errores.
    """

    def load_manifest():
        if not os.path.exists(manifest_path):
            msg = f"Manifest file not found at {manifest_path}, run npm run build first."
            if logger:
                logger.error(msg)
            raise RuntimeError(msg)
        with open(manifest_path, "r") as f:
            return json.load(f)

    @app.context_processor
    def inject_vite_assets():
        def vitecss():
            if dev_mode:
                return f'<link rel="stylesheet" href="{dev_server_url}/assets/style.css" />'
            else:
                manifest = load_manifest()
                css_links = [f'<link rel="stylesheet" href="/src/dist/assets/{value["file"]}" />' for key, value in manifest.items() if key.endswith(".css")]
                return "\n".join(css_links)

        def vitejs(entry=None):
            nonce_value = nonce_provider() if nonce_provider else None
            nonce_attr = f' nonce="{nonce_value}"' if nonce_value else ""

            try:
                if dev_mode:
                    if os.path.exists(manifest_path):
                        manifest = load_manifest()
                        matched_entry = next((value for key, value in manifest.items() if value.get("name") == entry), None)
                        if matched_entry:
                            return f'<script type="module" src="{dev_server_url}/{matched_entry["src"]}"{nonce_attr} defer></script>'
                        else:
                            if logger:
                                logger.warning(f"No dev manifest entry found for '{entry}'")
                            return ""
                    else:
                        if logger:
                            logger.warning("Manifest not found in dev mode, run npm run build first or adjust dev_server_url.")
                        return ""
                else:
                    manifest = load_manifest()
                    matched_entry = next((value for key, value in manifest.items() if key.endswith(f"{entry}.js")), None)
                    if matched_entry:
                        return f'<script type="module" src="/src/dist/{matched_entry["file"]}"{nonce_attr} defer></script>'
                    else:
                        raise RuntimeError(f"Entry '{entry}' not found in manifest")
            except Exception as e:
                if logger:
                    logger.exception(f"Error injecting Vite JS for entry '{entry}': {e}")
                return ""

        return dict(vitecss=vitecss, vitejs=vitejs)

    return app
